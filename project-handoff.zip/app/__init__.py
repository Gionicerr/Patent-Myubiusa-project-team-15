"""Local requirements-analysis pipeline."""
